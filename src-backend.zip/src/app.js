require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const authRoutes         = require('./routes/auth');
const jobsRoutes         = require('./routes/jobs');        
const applicationsRoutes = require('./routes/applications');
const savedJobsRoutes    = require('./routes/savedJobs');
const profileRoutes      = require('./routes/profile');
const { errorHandler, notFound } = require('./middleware/errorHandler');

const app = express();

// ── Middleware ──────────────────────────────────────────────────────────────
const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:5173'];

app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);
    if (allowedOrigins.indexOf(origin) !== -1 || process.env.NODE_ENV !== 'production') {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploaded files (Avatar images)
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// ── Health check ────────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ── Route Registration ──────────────────────────────────────────────────────
app.use('/api/auth',         authRoutes);
app.use('/api/jobs',         jobsRoutes);         
app.use('/api/applications', applicationsRoutes);
app.use('/api/saved-jobs',   savedJobsRoutes);

// Registering Profile routes under /api/user prefix
app.use('/api/user',         profileRoutes);

// ── Error handling ──────────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

module.exports = app;