const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const { getProfile, updateProfile, updateAvatar } = require('../controllers/profileController');

// Multer Configuration for Avatar Uploads
const avatarUpload = require('multer')({
  storage: require('multer').diskStorage({
    destination: (req, file, cb) => {
      const fs = require('fs');
      const path = require('path');
      const dir = path.join(__dirname, '../../uploads/avatars');
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      const path = require('path');
      const ext = path.extname(file.originalname);
      cb(null, `${req.user.id}-avatar${ext}`);
    },
  }),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Only image files allowed'), false);
  },
});

// GET /api/user/profile/:id
router.get('/profile/:id', getProfile);

// PUT /api/user/profile/:id (Requires Authentication)
router.put('/profile/:id', authenticate, updateProfile);

// POST /api/user/profile/avatar (Requires Authentication)
router.post('/avatar', authenticate, avatarUpload.single('avatar'), updateAvatar);

module.exports = router;