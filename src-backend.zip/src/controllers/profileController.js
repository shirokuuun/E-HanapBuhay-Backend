const { query } = require("../config/db");
const { sendSuccess, sendError } = require("../middleware/errorHandler");

/**
 * GET /api/user/profile/:id
 * Fetches combined User and Business Profile data
 */
const getProfile = async (req, res) => {
  try {
    const { id } = req.params; // Matches the :id parameter from the route

    const result = await query(
      `SELECT u.id, u.full_name, u.email, u.role, u.location, u.phone_number, u.avatar_url,
              bp.company_name, bp.company_size, bp.industry, bp.registration_number, bp.tax_id
       FROM users u
       LEFT JOIN business_profiles bp ON u.id = bp.user_id
       WHERE u.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return sendError(res, "User not found", 404);
    }

    const row = result.rows[0];
    
    // Formatting data to match React state (INITIAL_PROFILE & INITIAL_BUSINESS)
    const data = {
      full_name: row.full_name,
      email: row.email,
      location: row.location,
      role: row.role,
      avatar_url: row.avatar_url,
      business: {
        companyName: row.company_name,
        companySize: row.company_size,
        industry: row.industry,
        registrationNumber: row.registration_number,
        taxId: row.tax_id
      }
    };

    return sendSuccess(res, data);
  } catch (err) {
    console.error("getProfile Error:", err);
    return sendError(res, "Failed to fetch profile");
  }
};

/**
 * PUT /api/user/profile/:id
 * Updates basic user information
 */
const updateProfile = async (req, res) => {
  try {
    const { id } = req.params;
    const { full_name, location, phone_number } = req.body;

    const result = await query(
      `UPDATE users
       SET full_name    = COALESCE($1, full_name),
           location     = COALESCE($2, location),
           phone_number = COALESCE($3, phone_number),
           updated_at   = NOW()
       WHERE id = $4
       RETURNING id, full_name, email, role, location, phone_number, avatar_url`,
      [full_name, location, phone_number, id]
    );

    return sendSuccess(res, result.rows[0], "Profile updated");
  } catch (err) {
    console.error("updateProfile error:", err);
    return sendError(res, "Failed to update profile");
  }
};

/**
 * POST /api/user/profile/avatar
 * Handles avatar image updates
 */
const updateAvatar = async (req, res) => {
  try {
    if (!req.file) {
      return sendError(res, "No file uploaded", 400);
    }
    const avatar_url = `/uploads/avatars/${req.file.filename}`;
    const result = await query(
      "UPDATE users SET avatar_url = $1, updated_at = NOW() WHERE id = $2 RETURNING avatar_url",
      [avatar_url, req.user.id],
    );
    return sendSuccess(res, result.rows[0], "Avatar updated");
  } catch (err) {
    return sendError(res, "Failed to update avatar");
  }
};

module.exports = { getProfile, updateProfile, updateAvatar };